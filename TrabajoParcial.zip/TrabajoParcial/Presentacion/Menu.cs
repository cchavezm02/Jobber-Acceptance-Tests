﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Presentacion
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }
        string Encrypt(string chain)
        {
            string result = string.Empty;
            //Se coge caracter por caracter y lo envia al arreglo para hacer la encriptación
            Byte[] encrypt = System.Text.Encoding.Unicode.GetBytes(chain);
            result = Convert.ToBase64String(encrypt);
            return result;

        }
        private void encriptarToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.textBox1.Text = Encrypt(this.textBox1.Text);
        }
        string Decrypt(string chain)
        {
            string result = string.Empty;
            Byte[] decrypt = Convert.FromBase64String(chain);

            result = System.Text.Encoding.Unicode.GetString(decrypt);
            return result;

        }

        private void desencriptarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.textBox1.Text = Decrypt(this.textBox1.Text);
        }

        private void guardarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog save = new SaveFileDialog();
            save.Filter = "Archivo texto|*.txt";
            if (save.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter write = new StreamWriter(save.FileName))
                {
                    write.Write(this.textBox1.Text);
                }
            }
        }

        private void abrirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Archivo texto|*.txt";
            if (open.ShowDialog() == DialogResult.OK)
            {
                using (StreamReader read = new StreamReader(open.FileName))
                {
                    this.textBox1.Text = read.ReadToEnd();
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
        }
    }
}
